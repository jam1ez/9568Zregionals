bin/autons/pos/redsafe.cpp.o: src/autons/pos/redsafe.cpp
