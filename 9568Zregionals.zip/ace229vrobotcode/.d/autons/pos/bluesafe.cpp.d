bin/autons/pos/bluesafe.cpp.o: src/autons/pos/bluesafe.cpp
