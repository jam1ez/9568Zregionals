bin/autons/neg/redantirush.cpp.o: src/autons/neg/redantirush.cpp
