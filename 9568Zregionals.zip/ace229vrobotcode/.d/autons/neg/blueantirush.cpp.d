bin/autons/neg/blueantirush.cpp.o: src/autons/neg/blueantirush.cpp
